OrangeHRM

OrangeHRM is a comprehensive human resources management software that helps organizations manage their employee data, recruitment, performance management, training, and other HR functions.

INSTALLATION:
Use the package manager pip to install pytest.

--> pip install pytest
--> pip install pytest-html

USAGE:
The objective of this project is to develop automated test cases using testing frameworks like Selenium to validate the functionality and performance of the OrangeHRM website. The test cases will cover a range of scenarios including user authentication, data input, system navigation, and report generation, ensuring comprehensive test coverage for the website.

TESTCASES COVERED:
1. Validate forgot password link and message.
2. Validate header title and header options.
3. Validate main menu options.



LISENCE:
OrangeHRM